package com.example.recyclerviewexample

data class SampleModel(val id:Int , val name: String)
